package com.example.myrecyclerview;

import java.util.List;

public class CharBean {



    private int status;
    private String msg;
    private String zz;
    private String tm;
    private String url;

    public CharBean(int status, String msg, String zz, String tm, String url) {
        this.status = status;
        this.msg = msg;
        this.zz = zz;
        this.tm = tm;
        this.url = url;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getZz() {
        return zz;
    }

    public void setZz(String zz) {
        this.zz = zz;
    }

    public String getTm() {
        return tm;
    }

    public void setTm(String tm) {
        this.tm = tm;
    }


    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }




}

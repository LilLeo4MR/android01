package com.example.myrecyclerview;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.myrecyclerview.base.BaseRecyclerAdapter;
import com.example.myrecyclerview.base.MyRVViewHolder;

import org.litepal.crud.DataSupport;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends Activity {

    @BindView(R.id.tv_0)
    TextView tv_0;
    @BindView(R.id.tv_1)
    TextView tv_1;
    @BindView(R.id.tv_2)
    TextView tv_2;
    @BindView(R.id.tv_3)
    TextView tv_3;
    @BindView(R.id.lv)
    RecyclerView lv;


    private List<CharBean> itemBeanList = new ArrayList();
    private MyAdapter myAdapter;

    @SuppressLint("WrongConstant")
    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);



        @SuppressLint("WrongConstant")
        LinearLayoutManager manager = new LinearLayoutManager(MainActivity.this, LinearLayoutManager.VERTICAL, false);
        if (null == manager)
            return;
        lv.setLayoutManager(manager);
        myAdapter = new MyAdapter(MainActivity.this, itemBeanList, R.layout.item_meal);
        lv.setAdapter(myAdapter);
        myAdapter.setOnItemClickListener(new BaseRecyclerAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                Intent intent = new Intent(MainActivity.this,WebActivity.class);
                intent.putExtra("url",itemBeanList.get(position).getUrl());
                startActivity(intent);
            }
        });


        setSelPosit(0);
        tv_0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setSelPosit(0);
            }
        });

        tv_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setSelPosit(1);
            }
        });

        tv_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setSelPosit(2);
            }
        });

        tv_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setSelPosit(3);
            }
        });

    }


    private void setSelPosit(int pos) {
        itemBeanList.clear();
        switch (pos) {
            case 0:
                tv_0.setTextColor(getResources().getColor(R.color.color_3853e8));
                tv_1.setTextColor(getResources().getColor(R.color.color_black));
                tv_2.setTextColor(getResources().getColor(R.color.color_black));
                tv_3.setTextColor(getResources().getColor(R.color.color_black));
                itemBeanList.add(new CharBean(
                        R.mipmap.q1,
                        "大坂直美超小威成收入最高女运动员 3740万创历史",
                        "新浪新闻",
                        "11分钟前"
                        ,"https://sports.sina.com.cn/tennis/wta/2020-05-23/doc-iircuyvi4589130.shtml"
                ));
                itemBeanList.add(new CharBean(
                        R.mipmap.im1,
                        "爬楼救下悬空6楼女童，救人小哥被海尔总部奖励一套价值60万元房产",
                        "红星新闻",
                        "31分钟前"
                        ,"https://baijiahao.baidu.com/s?id=1667372026392808937&wfr=spider&for=pc"
                ));
                itemBeanList.add(new CharBean(
                        R.mipmap.a2,
                        "再造一个“北上广”？3个即将腾飞的城市",
                        "红星新闻",
                        "41分钟前"
                        ,"https://baijiahao.baidu.com/s?id=1667370872117851681&wfr=spider&for=pc"
                ));
                itemBeanList.add(new CharBean(
                        R.mipmap.a3,
                        "昨夜今晨世界疫情一览：全球累计确诊逾507万例 美国新增超2.5万例",
                        "中华网",
                        "23分钟前"
                        ,"https://baijiahao.baidu.com/s?id=1667345346113186218&wfr=spider&for=pc"
                ));
                itemBeanList.add(new CharBean(
                        R.mipmap.a4,
                        "酒局上，领导说：“帮我买包烟”，笨蛋才去买，有眼力人都这样做",
                        "娱乐网",
                        "1小时前"
                        ,"https://baijiahao.baidu.com/s?id=1667308177508485539&wfr=spider&for=pc"
                ));
                itemBeanList.add(new CharBean(
                        R.mipmap.a5,
                        "动物的“自杀性交配”是怎么回事？",
                        "娱乐网",
                        "2小时前"
                        ,"https://baijiahao.baidu.com/s?id=1666748537976591287&wfr=spider&for=pc"
                ));
                itemBeanList.add(new CharBean(
                        R.mipmap.a6,
                        "1997年，宋丹丹出轨3天后，致电英达：我有外遇了，咱们离婚吧",
                        "红星新闻",
                        "1天前"
                        ,"https://baijiahao.baidu.com/s?id=1666262252419352938&wfr=spider&for=pc"
                ));
                itemBeanList.add(new CharBean(
                        R.mipmap.a7,
                        "肖战无奈再发文，为什么大家还是不放过肖战？",
                        "百度新闻",
                        "1天前"
                        ,"https://baijiahao.baidu.com/s?id=1666473249170395458&wfr=spider&for=pc"
                ));
                itemBeanList.add(new CharBean(
                        R.mipmap.a8,
                        "Caps直播谈LPL训练赛战绩：FPX成大赢家，IG能够随意吊打",
                        "网易新闻",
                        "1天前"
                        ,"https://3g.163.com/news/article_cambrian/FD7NJPN105467CPO.html?from=history-back-list"
                ));
                itemBeanList.add(new CharBean(
                        R.mipmap.yq1,
                        "美国造假疫情数据？美科学家说出秘密……",
                        "娱乐网",
                        "2小时前"
                        ,"https://baijiahao.baidu.com/s?id=1667459524447276956&wfr=spider&for=pc"
                ));
                itemBeanList.add(new CharBean(
                        R.mipmap.yq2,
                        "疫情催化 德国华人旧业创“新篇”",
                        "中国新闻网",
                        "1天前"
                        ,"https://baijiahao.baidu.com/s?id=1667460969657279121&wfr=spider&for=pc"
                ));
                itemBeanList.add(new CharBean(
                        R.mipmap.yq3,
                        "后疫情时期健康中国如何建设",
                        "人民网",
                        "1天前"
                        ,"http://news.ifeng.com/c/7wi2Mpirzv6"
                ));
                itemBeanList.add(new CharBean(
                        R.mipmap.yq4,
                        "《柳叶刀》发表陈薇院士团队新冠疫苗最新研究成果：安全且有效",
                        "经济观察报",
                        "1天前"
                        ,"https://www.sohu.com/a/397068974_118622?_trans_=000014_bdss_dkwhfy"
                ));
                break;
            case 1:
                tv_0.setTextColor(getResources().getColor(R.color.color_black));
                tv_1.setTextColor(getResources().getColor(R.color.color_3853e8));
                tv_2.setTextColor(getResources().getColor(R.color.color_black));
                tv_3.setTextColor(getResources().getColor(R.color.color_black));
                itemBeanList.add(new CharBean(
                        R.mipmap.a,
                        "中信银行的支行行长被撤职，长沙光大、工商、邮储银行工作人员被刑拘",
                        "人民日报",
                        "11分钟前"
                        ,"https://baijiahao.baidu.com/s?id=1667402144200576284&wfr=spider&for=pc"
                ));
                itemBeanList.add(new CharBean(
                        R.mipmap.im1,
                        "爬楼救下悬空6楼女童，救人小哥被海尔总部奖励一套价值60万元房产",
                        "红星新闻",
                        "31分钟前"
                        ,"https://baijiahao.baidu.com/s?id=1667372026392808937&wfr=spider&for=pc"
                ));
                itemBeanList.add(new CharBean(
                        R.mipmap.a2,
                        "再造一个“北上广”？3个即将腾飞的城市",
                        "红星新闻",
                        "41分钟前"
                        ,"https://baijiahao.baidu.com/s?id=1667370872117851681&wfr=spider&for=pc"
                ));
                itemBeanList.add(new CharBean(
                        R.mipmap.a3,
                        "昨夜今晨世界疫情一览：全球累计确诊逾507万例 美国新增超2.5万例",
                        "中华网",
                        "23分钟前"
                        ,"https://baijiahao.baidu.com/s?id=1667345346113186218&wfr=spider&for=pc"
                ));
                break;
            case 2:
                tv_0.setTextColor(getResources().getColor(R.color.color_black));
                tv_1.setTextColor(getResources().getColor(R.color.color_black));
                tv_2.setTextColor(getResources().getColor(R.color.color_3853e8));
                tv_3.setTextColor(getResources().getColor(R.color.color_black));

                itemBeanList.add(new CharBean(
                        R.mipmap.a5,
                        "动物的“自杀性交配”是怎么回事？",
                        "娱乐网",
                        "2小时前"
                        ,"https://baijiahao.baidu.com/s?id=1666748537976591287&wfr=spider&for=pc"
                ));
                itemBeanList.add(new CharBean(
                        R.mipmap.a6,
                        "1997年，宋丹丹出轨3天后，致电英达：我有外遇了，咱们离婚吧",
                        "红星新闻",
                        "1天前"
                        ,"https://baijiahao.baidu.com/s?id=1666262252419352938&wfr=spider&for=pc"
                ));
                itemBeanList.add(new CharBean(
                        R.mipmap.a7,
                        "肖战无奈再发文，为什么大家还是不放过肖战？",
                        "百度新闻",
                        "1天前"
                        ,"https://baijiahao.baidu.com/s?id=1666473249170395458&wfr=spider&for=pc"
                ));
                itemBeanList.add(new CharBean(
                        R.mipmap.a8,
                        "Caps直播谈LPL训练赛战绩：FPX成大赢家，IG能够随意吊打",
                        "网易新闻",
                        "1天前"
                        ,"https://3g.163.com/news/article_cambrian/FD7NJPN105467CPO.html?from=history-back-list"
                ));

            case 3:
                tv_0.setTextColor(getResources().getColor(R.color.color_black));
                tv_1.setTextColor(getResources().getColor(R.color.color_black));
                tv_2.setTextColor(getResources().getColor(R.color.color_black));
                tv_3.setTextColor(getResources().getColor(R.color.color_3853e8));

                itemBeanList.add(new CharBean(
                        R.mipmap.yq1,
                        "美国造假疫情数据？美科学家说出秘密……",
                        "娱乐网",
                        "2小时前"
                        ,"https://baijiahao.baidu.com/s?id=1667459524447276956&wfr=spider&for=pc"
                ));
                itemBeanList.add(new CharBean(
                        R.mipmap.yq2,
                        "疫情催化 德国华人旧业创“新篇”",
                        "中国新闻网",
                        "1天前"
                        ,"https://baijiahao.baidu.com/s?id=1667460969657279121&wfr=spider&for=pc"
                ));
                itemBeanList.add(new CharBean(
                        R.mipmap.yq3,
                        "后疫情时期健康中国如何建设",
                        "人民网",
                        "1天前"
                        ,"http://news.ifeng.com/c/7wi2Mpirzv6"
                ));
                itemBeanList.add(new CharBean(
                        R.mipmap.yq4,
                        "《柳叶刀》发表陈薇院士团队新冠疫苗最新研究成果：安全且有效",
                        "经济观察报",
                        "1天前"
                        ,"https://www.sohu.com/a/397068974_118622?_trans_=000014_bdss_dkwhfy"
                ));

                break;


        }




        myAdapter.notifyDataSetChanged();
    }


    @RequiresApi(api = Build.VERSION_CODES.N)
    class MyAdapter extends BaseRecyclerAdapter<CharBean > {
        private RelativeLayout layout_item;


        private int selPosi;

        public void setSelPosi(int selPosi) {
            this.selPosi = selPosi;
        }

        public MyAdapter(Context context, List<CharBean> datas, int layoutId) {
            super(context, datas, layoutId);
        }

        @Override
        public void setView(MyRVViewHolder holder, CharBean bean, int position) {
            if (null == holder || null == bean)
                return;
            //init view

            ImageView iv_s = holder.getView(R.id.iv_s);
            TextView tv_name = holder.getView(R.id.tv_name);
            TextView tv_zuoze = holder.getView(R.id.tv_zuoze);
            TextView tv_time = holder.getView(R.id.tv_time);
            //set view
            iv_s.setBackgroundResource( bean.getStatus());
            tv_name.setText(bean.getMsg());
            tv_time.setText(bean.getTm());
            tv_zuoze.setText(bean.getZz());
        }
    }

}

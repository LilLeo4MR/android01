package com.example.jpushdemo;


import cn.jpush.android.service.JCommonService;

public class PushService extends JCommonService {

}
